package com.cloudera.sa.copybook.mapreduce;

public class Const {
	public static final String COPYBOOK_INPUTFORMAT_CBL_HDFS_PATH_CONF = "copybook.inputformat.cbl.hdfs.path";
}
